"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Users,
  Film,
  Settings,
  BarChart3,
  Plus,
  Edit,
  Trash2,
  Eye,
  LogOut,
  Shield,
  Crown,
  Subtitles,
} from "lucide-react"
import { useAuth } from "../hooks/use-auth"
import type { Movie } from "../types/user"
import { useLanguage } from "../hooks/use-language"
import LanguageSwitcher from "./language-switcher"
import SubtitleManager from "./subtitle-manager"

const mockMovies: Movie[] = [
  {
    id: "1",
    title: "Big Buck Bunny",
    year: "2008",
    rating: 4.2,
    quality: "HD",
    poster: "https://storage.googleapis.com/gtv-videos-bucket/sample/images/BigBuckBunny.jpg",
    trailer: "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    duration: "10m",
    genre: ["Animation", "Comedy"],
    description:
      "A large and lovable rabbit deals with three tiny bullies, led by a flying squirrel, who are determined to squelch his happiness.",
    downloadUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
  },
  {
    id: "2",
    title: "Sintel",
    year: "2010",
    rating: 4.6,
    quality: "HD",
    poster: "https://storage.googleapis.com/gtv-videos-bucket/sample/images/Sintel.jpg",
    trailer: "https://storage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
    duration: "15m",
    genre: ["Animation", "Adventure"],
    description: "A lonely young woman, Sintel, helps and befriends a dragon, whom she calls Scales.",
    downloadUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
  },
]

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const [newMovieTitle, setNewMovieTitle] = useState("")
  const [selectedUserId, setSelectedUserId] = useState("")
  const [subscriptionDays, setSubscriptionDays] = useState("30")
  const { user, logout, getAllUsers, updateUserSubscription, isSubscriptionActive } = useAuth()
  const { t, isRTL } = useLanguage()

  const allUsers = getAllUsers()
  const stats = {
    totalUsers: allUsers.length,
    totalMovies: mockMovies.length,
    activeSubscriptions: allUsers.filter((u) => isSubscriptionActive(u)).length,
    monthlyRevenue: allUsers.filter((u) => isSubscriptionActive(u)).length * 20000,
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString() + " " + date.toLocaleTimeString()
  }

  const getRemainingDays = (user: any) => {
    if (user.subscriptionExpiry) {
      const now = new Date()
      const expiry = new Date(user.subscriptionExpiry)
      const diffTime = expiry.getTime() - now.getTime()
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
      return Math.max(0, diffDays)
    }
    return 0
  }

  const handleGrantSubscription = (userId: string, days: number) => {
    updateUserSubscription(userId, "premium", days)
    setSelectedUserId("")
    setSubscriptionDays("30")
  }

  const handleRevokeSubscription = (userId: string) => {
    updateUserSubscription(userId, "free")
  }

  const renderOverview = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">{t("admin.total_users")}</p>
                <p className="text-2xl font-bold text-white">{stats.totalUsers}</p>
              </div>
              <Users className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">{t("admin.total_movies")}</p>
                <p className="text-2xl font-bold text-white">{stats.totalMovies}</p>
              </div>
              <Film className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">{t("admin.active_subscriptions")}</p>
                <p className="text-2xl font-bold text-white">{stats.activeSubscriptions}</p>
              </div>
              <Crown className="w-8 h-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">{t("admin.monthly_revenue")}</p>
                <p className="text-2xl font-bold text-white">{stats.monthlyRevenue.toLocaleString()} تومان</p>
              </div>
              <BarChart3 className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">{t("admin.recent_activity")}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {allUsers
              .slice(-5)
              .reverse()
              .map((user, index) => (
                <div key={user.id} className="flex items-center gap-3 p-3 bg-gray-700 rounded-lg">
                  <div
                    className={`w-2 h-2 rounded-full ${isSubscriptionActive(user) ? "bg-green-500" : "bg-gray-500"}`}
                  ></div>
                  <span className="text-white">
                    User {user.name} ({user.email}) - {isSubscriptionActive(user) ? "Premium" : "Free"}
                  </span>
                  <span className="text-gray-400 text-sm ml-auto">{formatDate(user.lastLogin)}</span>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderUsers = () => (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Grant Premium Subscription</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 items-end">
            <div className="flex-1">
              <label className="text-gray-400 text-sm">Select User</label>
              <select
                value={selectedUserId}
                onChange={(e) => setSelectedUserId(e.target.value)}
                className="w-full mt-1 bg-gray-700 border-gray-600 text-white rounded px-3 py-2"
              >
                <option value="">Choose a user...</option>
                {allUsers.map((user) => (
                  <option key={user.id} value={user.id}>
                    {user.name} ({user.email})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-gray-400 text-sm">Days</label>
              <Input
                type="number"
                value={subscriptionDays}
                onChange={(e) => setSubscriptionDays(e.target.value)}
                className="w-20 bg-gray-700 border-gray-600 text-white"
                min="1"
              />
            </div>
            <Button
              onClick={() =>
                selectedUserId && handleGrantSubscription(selectedUserId, Number.parseInt(subscriptionDays))
              }
              disabled={!selectedUserId}
              className="bg-green-600 hover:bg-green-700"
            >
              Grant Premium
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">All Registered Users</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-700">
                  <th className="text-left text-gray-400 pb-3">Name</th>
                  <th className="text-left text-gray-400 pb-3">Email</th>
                  <th className="text-left text-gray-400 pb-3">Status</th>
                  <th className="text-left text-gray-400 pb-3">Expires</th>
                  <th className="text-left text-gray-400 pb-3">Registered</th>
                  <th className="text-left text-gray-400 pb-3">Last Login</th>
                  <th className="text-left text-gray-400 pb-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {allUsers.map((user) => (
                  <tr key={user.id} className="border-b border-gray-700">
                    <td className="py-3 text-white">{user.name}</td>
                    <td className="py-3 text-gray-300">{user.email}</td>
                    <td className="py-3">
                      <div className="flex items-center gap-2">
                        <span
                          className={`px-2 py-1 rounded text-xs ${
                            isSubscriptionActive(user)
                              ? "bg-green-500/20 text-green-400"
                              : "bg-gray-500/20 text-gray-400"
                          }`}
                        >
                          {isSubscriptionActive(user) ? "Premium" : "Free"}
                        </span>
                        {isSubscriptionActive(user) && (
                          <span className="text-yellow-400 text-xs">{getRemainingDays(user)} days left</span>
                        )}
                      </div>
                    </td>
                    <td className="py-3 text-gray-300 text-sm">
                      {user.subscriptionExpiry ? formatDate(new Date(user.subscriptionExpiry)) : "N/A"}
                    </td>
                    <td className="py-3 text-gray-300 text-sm">{formatDate(user.registrationDate)}</td>
                    <td className="py-3 text-gray-300 text-sm">{formatDate(user.lastLogin)}</td>
                    <td className="py-3">
                      <div className="flex gap-2">
                        {isSubscriptionActive(user) ? (
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-red-400 hover:bg-red-500/20"
                            onClick={() => handleRevokeSubscription(user.id)}
                          >
                            Revoke
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-green-400 hover:bg-green-500/20"
                            onClick={() => handleGrantSubscription(user.id, 30)}
                          >
                            Grant 30d
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderMovies = () => (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">{t("admin.add_new_movie")}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <Input
              placeholder={t("admin.movie_title")}
              value={newMovieTitle}
              onChange={(e) => setNewMovieTitle(e.target.value)}
              className="bg-gray-700 border-gray-600 text-white"
            />
            <Button className="bg-purple-500 hover:bg-purple-600">
              <Plus className="w-4 h-4 mr-2" />
              {t("admin.add_movie")}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">{t("admin.movie_management")}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mockMovies.map((movie) => (
              <div key={movie.id} className="bg-gray-700 rounded-lg p-4">
                <img
                  src={movie.poster || "/placeholder.svg"}
                  alt={movie.title}
                  className="w-full h-48 object-cover rounded-lg mb-3"
                />
                <h3 className="text-white font-medium mb-2">{movie.title}</h3>
                <p className="text-gray-400 text-sm mb-3">
                  {movie.year} • {movie.duration}
                </p>
                <div className="flex gap-2">
                  <Button size="sm" variant="ghost" className="text-blue-400 hover:bg-blue-500/20">
                    <Eye className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="ghost" className="text-yellow-400 hover:bg-yellow-500/20">
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="ghost" className="text-red-400 hover:bg-red-500/20">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )

  const renderSubtitles = () => <SubtitleManager />

  const renderSettings = () => (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">{t("admin.platform_settings")}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
            <div>
              <h4 className="text-white font-medium">Free Trial Period</h4>
              <p className="text-gray-400 text-sm">New users get 8 days of premium access</p>
            </div>
            <Button className="bg-green-600 hover:bg-green-700">8 Days</Button>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
            <div>
              <h4 className="text-white font-medium">Download Restrictions</h4>
              <p className="text-gray-400 text-sm">Only premium users can download movies</p>
            </div>
            <Button className="bg-green-600 hover:bg-green-700">Active</Button>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
            <div>
              <h4 className="text-white font-medium">Subtitle Support</h4>
              <p className="text-gray-400 text-sm">Persian and English subtitles enabled</p>
            </div>
            <Button className="bg-green-600 hover:bg-green-700">Enabled</Button>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Payment Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="bg-blue-900/20 border border-blue-500/50 rounded-lg p-4">
              <h4 className="text-blue-400 font-medium mb-2">Telegram Contact</h4>
              <p className="text-gray-300 text-sm mb-1">
                <strong>Username:</strong> @YOUNS_AT
              </p>
              <p className="text-gray-300 text-sm">Users can contact you directly for premium subscriptions</p>
            </div>

            <div className="bg-green-900/20 border border-green-500/50 rounded-lg p-4">
              <h4 className="text-green-400 font-medium mb-2">Bank Portal</h4>
              <p className="text-gray-300 text-sm mb-1">
                <strong>Link:</strong> https://bank-portal-link.com
              </p>
              <p className="text-gray-300 text-sm">Secure online payment gateway for subscriptions</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )

  return (
    <div className={`min-h-screen bg-gray-900 text-white ${isRTL ? "font-arabic" : ""}`}>
      {/* Admin Header */}
      <header className="bg-gray-800 border-b border-gray-700">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-r from-red-500 to-orange-500 p-2 rounded-lg">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">{t("admin.teloplay_admin")}</h1>
                <p className="text-gray-400 text-sm">{t("admin.admin_dashboard")}</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <LanguageSwitcher />
              <div className="text-right">
                <p className="text-white font-medium">{user?.name}</p>
                <p className="text-red-400 text-sm">{t("admin.administrator")}</p>
              </div>
              <Button onClick={logout} variant="ghost" className="text-red-400 hover:bg-red-500/20">
                <LogOut className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="flex gap-8">
          {/* Sidebar */}
          <div className="w-64 space-y-2">
            <Button
              onClick={() => setActiveTab("overview")}
              variant={activeTab === "overview" ? "default" : "ghost"}
              className="w-full justify-start"
            >
              <BarChart3 className="w-4 h-4 mr-2" />
              {t("admin.overview")}
            </Button>
            <Button
              onClick={() => setActiveTab("users")}
              variant={activeTab === "users" ? "default" : "ghost"}
              className="w-full justify-start"
            >
              <Users className="w-4 h-4 mr-2" />
              {t("admin.users")}
            </Button>
            <Button
              onClick={() => setActiveTab("movies")}
              variant={activeTab === "movies" ? "default" : "ghost"}
              className="w-full justify-start"
            >
              <Film className="w-4 h-4 mr-2" />
              {t("admin.movies")}
            </Button>
            <Button
              onClick={() => setActiveTab("subtitles")}
              variant={activeTab === "subtitles" ? "default" : "ghost"}
              className="w-full justify-start"
            >
              <Subtitles className="w-4 h-4 mr-2" />
              Subtitles
            </Button>
            <Button
              onClick={() => setActiveTab("settings")}
              variant={activeTab === "settings" ? "default" : "ghost"}
              className="w-full justify-start"
            >
              <Settings className="w-4 h-4 mr-2" />
              {t("admin.settings")}
            </Button>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {activeTab === "overview" && renderOverview()}
            {activeTab === "users" && renderUsers()}
            {activeTab === "movies" && renderMovies()}
            {activeTab === "subtitles" && renderSubtitles()}
            {activeTab === "settings" && renderSettings()}
          </div>
        </div>
      </div>
    </div>
  )
}
