"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Plus, Edit, Trash2, Download } from "lucide-react"

interface Subtitle {
  id: string
  language: string
  label: string
  content: string
  movieId: string
}

export default function SubtitleManager() {
  const [subtitles, setSubtitles] = useState<Subtitle[]>([
    {
      id: "1",
      language: "fa",
      label: "فارسی",
      content:
        "WEBVTT\n\n00:00:00.000 --> 00:00:05.000\nاین است اولین خط\n\n00:00:05.000 --> 00:00:10.000\nاین یک متن برای تست پلیر است",
      movieId: "1",
    },
    {
      id: "2",
      language: "en",
      label: "English",
      content:
        "WEBVTT\n\n00:00:00.000 --> 00:00:05.000\nThis is the first line\n\n00:00:05.000 --> 00:00:10.000\nThis is a test subtitle for the player",
      movieId: "1",
    },
  ])

  const [newSubtitle, setNewSubtitle] = useState({
    language: "",
    label: "",
    content: "",
    movieId: "1",
  })

  const [editingId, setEditingId] = useState<string | null>(null)

  const handleAddSubtitle = () => {
    if (newSubtitle.language && newSubtitle.label && newSubtitle.content) {
      const subtitle: Subtitle = {
        id: Date.now().toString(),
        ...newSubtitle,
      }
      setSubtitles([...subtitles, subtitle])
      setNewSubtitle({ language: "", label: "", content: "", movieId: "1" })
    }
  }

  const handleDeleteSubtitle = (id: string) => {
    setSubtitles(subtitles.filter((sub) => sub.id !== id))
  }

  const handleEditSubtitle = (id: string) => {
    const subtitle = subtitles.find((sub) => sub.id === id)
    if (subtitle) {
      setNewSubtitle(subtitle)
      setEditingId(id)
    }
  }

  const handleUpdateSubtitle = () => {
    if (editingId) {
      setSubtitles(subtitles.map((sub) => (sub.id === editingId ? { ...newSubtitle, id: editingId } : sub)))
      setEditingId(null)
      setNewSubtitle({ language: "", label: "", content: "", movieId: "1" })
    }
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        const content = e.target?.result as string
        setNewSubtitle((prev) => ({ ...prev, content }))
      }
      reader.readAsText(file)
    }
  }

  const downloadSubtitle = (subtitle: Subtitle) => {
    const blob = new Blob([subtitle.content], { type: "text/vtt" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${subtitle.label}.vtt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">{editingId ? "Edit Subtitle" : "Add New Subtitle"}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-gray-400 text-sm">Language Code</label>
              <Input
                placeholder="fa, en, ar, etc."
                value={newSubtitle.language}
                onChange={(e) => setNewSubtitle((prev) => ({ ...prev, language: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <label className="text-gray-400 text-sm">Display Label</label>
              <Input
                placeholder="فارسی, English, etc."
                value={newSubtitle.label}
                onChange={(e) => setNewSubtitle((prev) => ({ ...prev, label: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
          </div>

          <div>
            <label className="text-gray-400 text-sm">Subtitle Content (WebVTT format)</label>
            <textarea
              placeholder="WEBVTT&#10;&#10;00:00:00.000 --> 00:00:05.000&#10;First subtitle line&#10;&#10;00:00:05.000 --> 00:00:10.000&#10;Second subtitle line"
              value={newSubtitle.content}
              onChange={(e) => setNewSubtitle((prev) => ({ ...prev, content: e.target.value }))}
              className="w-full h-32 bg-gray-700 border-gray-600 text-white rounded px-3 py-2 text-sm font-mono"
            />
          </div>

          <div className="flex gap-4">
            <div>
              <label className="text-gray-400 text-sm">Upload VTT File</label>
              <input
                type="file"
                accept=".vtt,.srt"
                onChange={handleFileUpload}
                className="block w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-purple-500 file:text-white hover:file:bg-purple-600"
              />
            </div>
          </div>

          <div className="flex gap-2">
            {editingId ? (
              <>
                <Button onClick={handleUpdateSubtitle} className="bg-green-600 hover:bg-green-700">
                  <Edit className="w-4 h-4 mr-2" />
                  Update Subtitle
                </Button>
                <Button
                  onClick={() => {
                    setEditingId(null)
                    setNewSubtitle({ language: "", label: "", content: "", movieId: "1" })
                  }}
                  variant="outline"
                  className="border-gray-600 text-gray-400"
                >
                  Cancel
                </Button>
              </>
            ) : (
              <Button onClick={handleAddSubtitle} className="bg-purple-500 hover:bg-purple-600">
                <Plus className="w-4 h-4 mr-2" />
                Add Subtitle
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Existing Subtitles</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {subtitles.map((subtitle) => (
              <div key={subtitle.id} className="bg-gray-700 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h3 className="text-white font-medium">{subtitle.label}</h3>
                    <p className="text-gray-400 text-sm">Language: {subtitle.language}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-blue-400 hover:bg-blue-500/20"
                      onClick={() => handleEditSubtitle(subtitle.id)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-green-400 hover:bg-green-500/20"
                      onClick={() => downloadSubtitle(subtitle)}
                    >
                      <Download className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-red-400 hover:bg-red-500/20"
                      onClick={() => handleDeleteSubtitle(subtitle.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <div className="bg-gray-800 rounded p-2 text-xs text-gray-300 font-mono max-h-20 overflow-y-auto">
                  {subtitle.content.substring(0, 200)}...
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
