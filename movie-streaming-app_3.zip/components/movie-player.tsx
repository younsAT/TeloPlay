"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { X, Play, Pause, Volume2, VolumeX, Maximize, SkipBack, SkipForward, RefreshCw, Subtitles } from "lucide-react"
import type { Movie } from "../types/user"
import { useLanguage } from "../hooks/use-language"

interface MoviePlayerProps {
  movie: Movie
  onClose: () => void
}

interface SubtitleTrack {
  id: string
  label: string
  language: string
  src: string
}

export default function MoviePlayer({ movie, onClose }: MoviePlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [volume, setVolume] = useState(1)
  const [isMuted, setIsMuted] = useState(false)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [showControls, setShowControls] = useState(true)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState("")
  const [retryCount, setRetryCount] = useState(0)
  const [showSubtitles, setShowSubtitles] = useState(false)
  const [selectedSubtitle, setSelectedSubtitle] = useState<string>("off")
  const [showSubtitleMenu, setShowSubtitleMenu] = useState(false)
  const [showSettings, setShowSettings] = useState(false)

  const videoRef = useRef<HTMLVideoElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const controlsTimeoutRef = useRef<NodeJS.Timeout>()

  const { t, language } = useLanguage()

  // Sample subtitle tracks (in a real app, these would come from your server)
  const subtitleTracks: SubtitleTrack[] = [
    {
      id: "persian",
      label: "فارسی",
      language: "fa",
      src: "data:text/vtt;base64,V0VCVlRUCgowMDowMDowMC4wMDAgLS0+IDAwOjAwOjA1LjAwMArigI7YsNin2YjbjNmGINin2LPYqiDYp9mI2YTbjNmGINiu2LcKCjAwOjAwOjA1LjAwMCAtLT4gMDA6MDA6MTAuMDAwCtin2LLYp9uM2YYg2YXYqtmGINio2LHYp9uMINiq2LPYqiDZvtmE24zYsSDYp9iz2KoKCjAwOjAwOjEwLjAwMCAtLT4gMDA6MDA6MTUuMDAwCtin24zZhiDZgdmK2YTZhSDYqNix2KfbjCDZhtmF2KfbjNi0INiy24zYsdmG2YjbjNizINmB2KfYsdiz24wg2KfYs9iqCgowMDowMDoxNS4wMDAgLS0+IDAwOjAwOjIwLjAwMArigI7Yp9mF24zYr9mI2KfYsduM2YUg2qnZhyDYp9mK2YYg2YHbjNmE2YUg2LHYpyDYr9mI2LPYqiDYr9in2LHbjNivCgowMDowMDoyMC4wMDAgLS0+IDAwOjAwOjI1LjAwMArigI7Yp9iy2YXYp9uM2LQg2qnZhtmK2K8g2Ygg2KfYsiDYqtmF2KfYtNin24wg2qnYsdiv2YbYjAo=",
    },
    {
      id: "english",
      label: "English",
      language: "en",
      src: "data:text/vtt;base64,V0VCVlRUCgowMDowMDowMC4wMDAgLS0+IDAwOjAwOjA1LjAwMArigI5UaGlzIGlzIHRoZSBmaXJzdCBsaW5lCgowMDowMDowNS4wMDAgLS0+IDAwOjAwOjEwLjAwMArigI5UaGlzIGlzIGEgdGVzdCBzdWJ0aXRsZSBmb3IgdGhlIHBsYXllcgoKMDA6MDA6MTAuMDAwIC0tPiAwMDowMDoxNS4wMDAK4oCOVGhpcyBmaWxtIGlzIGZvciBkZW1vbnN0cmF0aW9uIHB1cnBvc2VzCgowMDowMDoxNS4wMDAgLS0+IDAwOjAwOjIwLjAwMArigI5XZSBob3BlIHlvdSBlbmpveSB3YXRjaGluZyB0aGlzIGZpbG0KCjAwOjAwOjIwLjAwMCAtLT4gMDA6MDA6MjUuMDAwCuKAjkVuam95IGFuZCBoYXZlIGZ1biB3YXRjaGluZyEK",
    },
  ]

  // More reliable video sources
  const videoSources = [
    movie.trailer,
    "https://www.w3schools.com/html/mov_bbb.mp4",
    "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
    "https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4",
    "https://file-examples.com/storage/fe68c1b7c66c4d2b8c4e8b5/2017/10/file_example_MP4_480_1_5MG.mp4",
  ]

  const [currentSourceIndex, setCurrentSourceIndex] = useState(0)

  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    const handleLoadedMetadata = () => {
      setDuration(video.duration)
      setIsLoading(false)
      setError("")
    }

    const handleTimeUpdate = () => {
      setCurrentTime(video.currentTime)
    }

    const handlePlay = () => {
      setIsPlaying(true)
    }

    const handlePause = () => {
      setIsPlaying(false)
    }

    const handleError = (e: Event) => {
      console.error("Video error:", e)

      // Try next source if available
      if (currentSourceIndex < videoSources.length - 1) {
        setCurrentSourceIndex((prev) => prev + 1)
        setIsLoading(true)
        setError("Trying alternative source...")
      } else {
        setError("Unable to load video. Please check your internet connection.")
        setIsLoading(false)
      }
    }

    const handleCanPlay = () => {
      setIsLoading(false)
      setError("")
    }

    const handleLoadStart = () => {
      setIsLoading(true)
    }

    video.addEventListener("loadedmetadata", handleLoadedMetadata)
    video.addEventListener("timeupdate", handleTimeUpdate)
    video.addEventListener("play", handlePlay)
    video.addEventListener("pause", handlePause)
    video.addEventListener("error", handleError)
    video.addEventListener("canplay", handleCanPlay)
    video.addEventListener("loadstart", handleLoadStart)

    return () => {
      video.removeEventListener("loadedmetadata", handleLoadedMetadata)
      video.removeEventListener("timeupdate", handleTimeUpdate)
      video.removeEventListener("play", handlePlay)
      video.removeEventListener("pause", handlePause)
      video.removeEventListener("error", handleError)
      video.removeEventListener("canplay", handleCanPlay)
      video.removeEventListener("loadstart", handleLoadStart)
    }
  }, [currentSourceIndex])

  // Load video source when index changes
  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    video.src = videoSources[currentSourceIndex]
    video.load()
  }, [currentSourceIndex])

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.code === "Space") {
        e.preventDefault()
        togglePlayPause()
      } else if (e.code === "Escape") {
        onClose()
      }
    }

    document.addEventListener("keydown", handleKeyPress)
    return () => document.removeEventListener("keydown", handleKeyPress)
  }, [])

  const formatTime = (seconds: number) => {
    if (isNaN(seconds)) return "0:00"
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = Math.floor(seconds % 60)

    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
    }
    return `${minutes}:${secs.toString().padStart(2, "0")}`
  }

  const togglePlayPause = () => {
    const video = videoRef.current
    if (!video) return

    if (video.paused) {
      video.play().catch((err) => {
        console.error("Play error:", err)
        setError("Failed to play video. Please try again.")
      })
    } else {
      video.pause()
    }
  }

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const video = videoRef.current
    if (!video || !duration) return

    const rect = e.currentTarget.getBoundingClientRect()
    const clickX = e.clientX - rect.left
    const newTime = (clickX / rect.width) * duration
    video.currentTime = newTime
  }

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const video = videoRef.current
    if (!video) return

    const newVolume = Number.parseFloat(e.target.value)
    setVolume(newVolume)
    video.volume = newVolume
    setIsMuted(newVolume === 0)
  }

  const toggleMute = () => {
    const video = videoRef.current
    if (!video) return

    if (isMuted) {
      video.volume = volume
      setIsMuted(false)
    } else {
      video.volume = 0
      setIsMuted(true)
    }
  }

  const toggleFullscreen = () => {
    const container = containerRef.current
    if (!container) return

    if (!document.fullscreenElement) {
      container.requestFullscreen().catch(console.error)
      setIsFullscreen(true)
    } else {
      document.exitFullscreen().catch(console.error)
      setIsFullscreen(false)
    }
  }

  const skipTime = (seconds: number) => {
    const video = videoRef.current
    if (!video) return

    video.currentTime = Math.max(0, Math.min(video.currentTime + seconds, duration))
  }

  const showControlsTemporarily = () => {
    setShowControls(true)
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current)
    }
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) {
        setShowControls(false)
      }
    }, 3000)
  }

  const handleRetry = () => {
    setIsLoading(true)
    setError("")
    setCurrentSourceIndex(0)
    setRetryCount((prev) => prev + 1)
  }

  const handleSubtitleChange = (subtitleId: string) => {
    const video = videoRef.current
    if (!video) return

    // Remove existing tracks
    const tracks = video.querySelectorAll("track")
    tracks.forEach((track) => track.remove())

    if (subtitleId === "off") {
      setSelectedSubtitle("off")
      setShowSubtitles(false)
    } else {
      const subtitle = subtitleTracks.find((track) => track.id === subtitleId)
      if (subtitle) {
        const track = document.createElement("track")
        track.kind = "subtitles"
        track.src = subtitle.src
        track.srclang = subtitle.language
        track.label = subtitle.label
        track.default = true
        video.appendChild(track)

        setSelectedSubtitle(subtitleId)
        setShowSubtitles(true)
      }
    }
    setShowSubtitleMenu(false)
  }

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 bg-black z-50 flex flex-col"
      onMouseMove={showControlsTemporarily}
      onMouseLeave={() => isPlaying && setShowControls(false)}
    >
      {/* Header */}
      <div
        className={`absolute top-0 left-0 right-0 z-10 bg-gradient-to-b from-black/80 to-transparent transition-opacity duration-300 ${showControls ? "opacity-100" : "opacity-0"}`}
      >
        <div className="flex items-center justify-between p-4">
          <div>
            <h1 className="text-white text-xl font-bold">{movie.title}</h1>
            <p className="text-gray-300 text-sm">
              {movie.year} • {movie.duration}
            </p>
          </div>
          <Button onClick={onClose} variant="ghost" size="icon" className="text-white hover:bg-white/20">
            <X className="w-6 h-6" />
          </Button>
        </div>
      </div>

      {/* Video Player */}
      <div className="flex-1 relative bg-black flex items-center justify-center">
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/50 z-10">
            <div className="text-center">
              <div className="w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mb-4"></div>
              <p className="text-white">Loading video...</p>
              {currentSourceIndex > 0 && (
                <p className="text-gray-400 text-sm">
                  Trying source {currentSourceIndex + 1} of {videoSources.length}
                </p>
              )}
            </div>
          </div>
        )}

        {error && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/50 z-10">
            <div className="text-center max-w-md p-6 bg-gray-800 rounded-lg">
              <p className="text-red-400 mb-4">{error}</p>
              <p className="text-gray-300 mb-4">
                This could be due to network issues or browser restrictions. Try using a different browser or check your
                internet connection.
              </p>
              <Button onClick={handleRetry} className="bg-purple-500 hover:bg-purple-600 flex items-center gap-2">
                <RefreshCw className="w-4 h-4" />
                Try Again
              </Button>
            </div>
          </div>
        )}

        <video
          ref={videoRef}
          className="w-full h-full object-contain"
          poster={movie.poster}
          preload="metadata"
          crossOrigin="anonymous"
          onClick={togglePlayPause}
          playsInline
        >
          Your browser does not support the video tag.
        </video>

        {/* Play/Pause Overlay */}
        {!isPlaying && !isLoading && !error && (
          <div className="absolute inset-0 flex items-center justify-center">
            <Button
              onClick={togglePlayPause}
              className="bg-purple-500/80 hover:bg-purple-600/80 rounded-full w-20 h-20 p-0"
            >
              <Play className="w-10 h-10 ml-2" />
            </Button>
          </div>
        )}
      </div>

      {/* Controls */}
      <div
        className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 to-transparent transition-opacity duration-300 ${showControls ? "opacity-100" : "opacity-0"}`}
      >
        <div className="p-4">
          {/* Progress Bar */}
          <div className="mb-4">
            <div
              className="w-full bg-gray-700 rounded-full h-2 cursor-pointer hover:h-3 transition-all"
              onClick={handleSeek}
            >
              <div
                className="bg-purple-500 h-full rounded-full transition-all duration-100"
                style={{ width: duration ? `${(currentTime / duration) * 100}%` : "0%" }}
              />
            </div>
            <div className="flex justify-between text-xs text-gray-400 mt-1">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Control Buttons */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:bg-white/20"
                onClick={() => skipTime(-10)}
              >
                <SkipBack className="w-6 h-6" />
              </Button>

              <Button
                onClick={togglePlayPause}
                className="bg-purple-500 hover:bg-purple-600 rounded-full w-12 h-12"
                disabled={isLoading || !!error}
              >
                {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-1" />}
              </Button>

              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={() => skipTime(10)}>
                <SkipForward className="w-6 h-6" />
              </Button>

              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={toggleMute}>
                  {isMuted ? <VolumeX className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
                </Button>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={isMuted ? 0 : volume}
                  onChange={handleVolumeChange}
                  className="w-20 h-1 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Subtitle Menu */}
              <div className="relative">
                <Button
                  variant="ghost"
                  size="icon"
                  className={`text-white hover:bg-white/20 ${showSubtitles ? "bg-purple-500/50" : ""}`}
                  onClick={() => setShowSubtitleMenu(!showSubtitleMenu)}
                >
                  <Subtitles className="w-6 h-6" />
                </Button>

                {showSubtitleMenu && (
                  <div className="absolute bottom-full right-0 mb-2 bg-gray-800 rounded-lg shadow-lg border border-gray-700 py-2 min-w-[150px]">
                    <div className="px-3 py-1 text-gray-400 text-xs font-medium border-b border-gray-700 mb-1">
                      Subtitles
                    </div>
                    <button
                      onClick={() => handleSubtitleChange("off")}
                      className={`w-full px-3 py-2 text-left text-white hover:bg-gray-700 text-sm ${selectedSubtitle === "off" ? "bg-purple-500/30" : ""}`}
                    >
                      Off
                    </button>
                    {subtitleTracks.map((track) => (
                      <button
                        key={track.id}
                        onClick={() => handleSubtitleChange(track.id)}
                        className={`w-full px-3 py-2 text-left text-white hover:bg-gray-700 text-sm ${selectedSubtitle === track.id ? "bg-purple-500/30" : ""}`}
                      >
                        {track.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20" onClick={toggleFullscreen}>
                <Maximize className="w-6 h-6" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
