"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { X, MessageCircle, CreditCard, Clock, Crown } from "lucide-react"
import { useLanguage } from "../hooks/use-language"

interface SubscriptionModalProps {
  isOpen: boolean
  onClose: () => void
}

export default function SubscriptionModal({ isOpen, onClose }: SubscriptionModalProps) {
  const { t } = useLanguage()
  const [selectedPlan, setSelectedPlan] = useState<"monthly" | "yearly">("monthly")

  if (!isOpen) return null

  const plans = {
    monthly: {
      price: "20,000 تومان",
      duration: "30 days",
      savings: "",
    },
    yearly: {
      price: "200,000 تومان",
      duration: "365 days",
      savings: "Save 17%",
    },
  }

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl bg-gray-900 border-gray-700 text-white">
        <CardHeader className="relative">
          <Button
            onClick={onClose}
            variant="ghost"
            size="icon"
            className="absolute right-4 top-4 text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </Button>
          <div className="text-center">
            <Crown className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
            <CardTitle className="text-2xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
              Upgrade to Premium
            </CardTitle>
            <p className="text-gray-400 mt-2">Unlock unlimited downloads and premium features</p>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Plan Selection */}
          <div className="grid grid-cols-2 gap-4">
            <div
              onClick={() => setSelectedPlan("monthly")}
              className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                selectedPlan === "monthly"
                  ? "border-purple-500 bg-purple-500/10"
                  : "border-gray-600 hover:border-gray-500"
              }`}
            >
              <h3 className="font-semibold text-lg">Monthly</h3>
              <p className="text-2xl font-bold text-purple-400">{plans.monthly.price}</p>
              <p className="text-gray-400 text-sm">{plans.monthly.duration}</p>
            </div>

            <div
              onClick={() => setSelectedPlan("yearly")}
              className={`p-4 rounded-lg border-2 cursor-pointer transition-all relative ${
                selectedPlan === "yearly"
                  ? "border-purple-500 bg-purple-500/10"
                  : "border-gray-600 hover:border-gray-500"
              }`}
            >
              <div className="absolute -top-2 -right-2 bg-green-500 text-white text-xs px-2 py-1 rounded-full">
                {plans.yearly.savings}
              </div>
              <h3 className="font-semibold text-lg">Yearly</h3>
              <p className="text-2xl font-bold text-purple-400">{plans.yearly.price}</p>
              <p className="text-gray-400 text-sm">{plans.yearly.duration}</p>
            </div>
          </div>

          {/* Features */}
          <div className="bg-gray-800 rounded-lg p-4">
            <h4 className="font-semibold mb-3 text-yellow-400">Premium Features:</h4>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                Unlimited movie downloads
              </li>
              <li className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                4K quality streaming
              </li>
              <li className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                No advertisements
              </li>
              <li className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                Early access to new releases
              </li>
              <li className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                Multiple device support
              </li>
            </ul>
          </div>

          {/* Payment Methods */}
          <div className="space-y-4">
            <h4 className="font-semibold text-center">Choose Payment Method:</h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Telegram Payment */}
              <Card className="bg-gray-800 border-gray-600 hover:border-blue-500 transition-colors cursor-pointer">
                <CardContent className="p-4 text-center">
                  <MessageCircle className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                  <h5 className="font-semibold text-white">Telegram</h5>
                  <p className="text-gray-400 text-sm mb-3">Contact admin for payment</p>
                  <Button
                    className="w-full bg-blue-600 hover:bg-blue-700"
                    onClick={() => window.open("https://t.me/YOUNS_AT", "_blank")}
                  >
                    Contact @YOUNS_AT
                  </Button>
                </CardContent>
              </Card>

              {/* Bank Portal */}
              <Card className="bg-gray-800 border-gray-600 hover:border-green-500 transition-colors cursor-pointer">
                <CardContent className="p-4 text-center">
                  <CreditCard className="w-8 h-8 text-green-500 mx-auto mb-2" />
                  <h5 className="font-semibold text-white">Bank Portal</h5>
                  <p className="text-gray-400 text-sm mb-3">Secure online payment</p>
                  <Button
                    className="w-full bg-green-600 hover:bg-green-700"
                    onClick={() => window.open("https://bank-portal-link.com", "_blank")}
                  >
                    Pay with Bank
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Trial Info */}
          <div className="bg-blue-900/20 border border-blue-500/50 rounded-lg p-4 text-center">
            <Clock className="w-6 h-6 text-blue-400 mx-auto mb-2" />
            <p className="text-blue-300 text-sm">New users get 8 days free premium trial!</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
