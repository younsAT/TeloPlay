"use client"

import { useState } from "react"
import { Star, Play, Plus, Download, Lock } from "lucide-react"
import { Button } from "@/components/ui/button"
import MoviePlayer from "./movie-player"
import SubscriptionModal from "./subscription-modal"
import type { Movie } from "../types/user"
import { useAuth } from "../hooks/use-auth"
import { useLanguage } from "../hooks/use-language"

// Using more reliable video sources
const movies: Movie[] = [
  {
    id: "1",
    title: "Big Buck Bunny",
    year: "2008",
    rating: 4.2,
    quality: "HD",
    poster: "https://storage.googleapis.com/gtv-videos-bucket/sample/images/BigBuckBunny.jpg",
    trailer: "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    duration: "10m",
    genre: ["Animation", "Comedy"],
    description:
      "A large and lovable rabbit deals with three tiny bullies, led by a flying squirrel, who are determined to squelch his happiness.",
    downloadUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
  },
  {
    id: "2",
    title: "Elephant Dream",
    year: "2006",
    rating: 4.1,
    quality: "HD",
    poster: "https://storage.googleapis.com/gtv-videos-bucket/sample/images/ElephantsDream.jpg",
    trailer: "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    duration: "11m",
    genre: ["Animation", "Fantasy"],
    description:
      "The first open movie from the Blender Foundation, featuring two strange characters exploring a surreal world.",
    downloadUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
  },
  {
    id: "3",
    title: "Sintel",
    year: "2010",
    rating: 4.6,
    quality: "HD",
    poster: "https://storage.googleapis.com/gtv-videos-bucket/sample/images/Sintel.jpg",
    trailer: "https://storage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
    duration: "15m",
    genre: ["Animation", "Adventure"],
    description: "A lonely young woman, Sintel, helps and befriends a dragon, whom she calls Scales.",
    downloadUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
  },
  {
    id: "4",
    title: "Tears of Steel",
    year: "2012",
    rating: 4.3,
    quality: "HD",
    poster: "https://storage.googleapis.com/gtv-videos-bucket/sample/images/TearsOfSteel.jpg",
    trailer: "https://storage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
    duration: "12m",
    genre: ["Action", "Sci-Fi"],
    description: "A group of warriors and scientists must fight to protect their city from strange robot invaders.",
    downloadUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
  },
  {
    id: "5",
    title: "Bunny Movie",
    year: "2022",
    rating: 4.7,
    quality: "HD",
    poster: "/placeholder.svg?height=300&width=200",
    trailer: "https://www.w3schools.com/html/mov_bbb.mp4",
    duration: "10s",
    genre: ["Animation", "Short"],
    description: "A short clip from the Big Buck Bunny movie, perfect for testing video playback.",
    downloadUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
  },
  {
    id: "6",
    title: "Flower",
    year: "2020",
    rating: 4.0,
    quality: "HD",
    poster: "/placeholder.svg?height=300&width=200",
    trailer: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
    duration: "6s",
    genre: ["Nature", "Short"],
    description: "A beautiful close-up video of a flower, perfect for testing short video playback.",
    downloadUrl: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
  },
  {
    id: "7",
    title: "For Bigger Fun",
    year: "2015",
    rating: 4.2,
    quality: "4K",
    poster: "https://storage.googleapis.com/gtv-videos-bucket/sample/images/ForBiggerFun.jpg",
    trailer: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
    duration: "60s",
    genre: ["Demo"],
    description: "A fun and engaging demo video perfect for testing video streaming quality.",
    downloadUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
  },
  {
    id: "8",
    title: "For Bigger Joyrides",
    year: "2015",
    rating: 4.4,
    quality: "4K",
    poster: "https://storage.googleapis.com/gtv-videos-bucket/sample/images/ForBiggerJoyrides.jpg",
    trailer: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
    duration: "15s",
    genre: ["Demo"],
    description: "An exciting joyride demo showcasing smooth video playback and quality.",
    downloadUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
  },
]

export default function MovieGrid() {
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null)
  const [hoveredMovie, setHoveredMovie] = useState<string | null>(null)
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false)
  const { user, isSubscriptionActive } = useAuth()
  const { t } = useLanguage()

  const canDownload = user && isSubscriptionActive(user)

  const handleDownload = (movie: Movie) => {
    if (canDownload) {
      // Create a temporary link to download the file
      const link = document.createElement("a")
      link.href = movie.downloadUrl || "#"
      link.download = `${movie.title}.mp4`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    } else {
      setShowSubscriptionModal(true)
    }
  }

  const getRemainingDays = () => {
    if (user && user.subscriptionExpiry) {
      const now = new Date()
      const expiry = new Date(user.subscriptionExpiry)
      const diffTime = expiry.getTime() - now.getTime()
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
      return Math.max(0, diffDays)
    }
    return 0
  }

  return (
    <>
      {/* Subscription Status Banner */}
      {user && (
        <div className="mb-6 p-4 rounded-lg bg-gradient-to-r from-purple-900/50 to-pink-900/50 border border-purple-500/30">
          <div className="flex items-center justify-between">
            <div>
              {isSubscriptionActive(user) ? (
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-green-400 font-medium">
                    Premium Active - {getRemainingDays()} days remaining
                  </span>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <span className="text-red-400 font-medium">Free Account - Upgrade for downloads</span>
                </div>
              )}
            </div>
            {!isSubscriptionActive(user) && (
              <Button
                onClick={() => setShowSubscriptionModal(true)}
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
              >
                Upgrade Now
              </Button>
            )}
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        {movies.map((movie) => (
          <div
            key={movie.id}
            className="relative group cursor-pointer"
            onMouseEnter={() => setHoveredMovie(movie.id)}
            onMouseLeave={() => setHoveredMovie(null)}
            onClick={() => setSelectedMovie(movie)} // Make entire card clickable
          >
            <div className="relative aspect-[2/3] rounded-lg overflow-hidden bg-gray-800 transition-transform duration-300 group-hover:scale-105">
              <img src={movie.poster || "/placeholder.svg"} alt={movie.title} className="w-full h-full object-cover" />

              {/* Quality Badge */}
              <div className="absolute top-2 left-2 bg-purple-500 text-white text-xs px-2 py-1 rounded font-bold">
                {movie.quality}
              </div>

              {/* Rating */}
              <div className="absolute top-2 right-2 flex items-center gap-1 bg-black/70 px-2 py-1 rounded">
                <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                <span className="text-xs text-white">{movie.rating}</span>
              </div>

              {/* Hover Overlay */}
              {hoveredMovie === movie.id && (
                <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                  <div className="flex gap-2">
                    <Button
                      onClick={(e) => {
                        e.stopPropagation()
                        setSelectedMovie(movie)
                      }}
                      className="bg-purple-500 hover:bg-purple-600 rounded-full w-12 h-12 p-0"
                    >
                      <Play className="w-5 h-5 ml-1" />
                    </Button>
                    <Button
                      variant="outline"
                      className="bg-transparent border-white text-white hover:bg-white hover:text-black rounded-full w-12 h-12 p-0"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Plus className="w-5 h-5" />
                    </Button>
                    <Button
                      onClick={(e) => {
                        e.stopPropagation()
                        handleDownload(movie)
                      }}
                      variant="outline"
                      className={`rounded-full w-12 h-12 p-0 ${
                        canDownload
                          ? "bg-green-500 border-green-500 text-white hover:bg-green-600"
                          : "bg-gray-500 border-gray-500 text-gray-300"
                      }`}
                    >
                      {canDownload ? <Download className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
                    </Button>
                  </div>
                </div>
              )}
            </div>

            {/* Movie Info */}
            <div className="mt-3">
              <h3 className="text-white font-medium text-sm truncate">{movie.title}</h3>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-gray-400 text-xs">{movie.year}</span>
                <span className="text-gray-500 text-xs">•</span>
                <span className="text-gray-400 text-xs">{movie.duration}</span>
              </div>
              <div className="flex gap-1 mt-1">
                {movie.genre.slice(0, 2).map((g) => (
                  <span key={g} className="text-purple-400 text-xs bg-purple-500/20 px-2 py-1 rounded">
                    {g}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Movie Player Modal */}
      {selectedMovie && <MoviePlayer movie={selectedMovie} onClose={() => setSelectedMovie(null)} />}

      {/* Subscription Modal */}
      <SubscriptionModal isOpen={showSubscriptionModal} onClose={() => setShowSubscriptionModal(false)} />
    </>
  )
}
