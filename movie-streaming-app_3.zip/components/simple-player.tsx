"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { X, Play } from "lucide-react"

interface SimplePlayerProps {
  videoUrl: string
  title: string
  onClose: () => void
}

export default function SimplePlayer({ videoUrl, title, onClose }: SimplePlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [error, setError] = useState("")
  const videoRef = useRef<HTMLVideoElement>(null)

  // Alternative video sources if the main one fails
  const alternativeSources = [
    "https://www.w3schools.com/html/mov_bbb.mp4",
    "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
  ]

  const [currentSourceIndex, setCurrentSourceIndex] = useState(-1) // -1 means use the original source

  const currentSource =
    currentSourceIndex === -1 ? videoUrl : alternativeSources[currentSourceIndex % alternativeSources.length]

  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    const handlePlay = () => setIsPlaying(true)
    const handlePause = () => setIsPlaying(false)
    const handleError = () => {
      console.error("Video error with source:", currentSource)
      setError("Failed to load video. Trying alternative source...")

      // Try next source
      setCurrentSourceIndex((prev) => (prev + 1) % alternativeSources.length)
    }

    video.addEventListener("play", handlePlay)
    video.addEventListener("pause", handlePause)
    video.addEventListener("error", handleError)

    return () => {
      video.removeEventListener("play", handlePlay)
      video.removeEventListener("pause", handlePause)
      video.removeEventListener("error", handleError)
    }
  }, [currentSource])

  // When source changes, reload the video
  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    video.load()
    video.play().catch((err) => {
      console.error("Play error:", err)
    })
  }, [currentSource])

  const togglePlayPause = () => {
    const video = videoRef.current
    if (!video) return

    if (video.paused) {
      video.play().catch((err) => {
        console.error("Play error:", err)
        setError("Failed to play video. Please try again.")
      })
    } else {
      video.pause()
    }
  }

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-gradient-to-b from-black/80 to-transparent">
        <div>
          <h1 className="text-white text-xl font-bold">{title}</h1>
          {error && <p className="text-red-400 text-sm">{error}</p>}
        </div>
        <Button onClick={onClose} variant="ghost" size="icon" className="text-white hover:bg-white/20">
          <X className="w-6 h-6" />
        </Button>
      </div>

      {/* Video Player */}
      <div className="flex-1 relative bg-black flex items-center justify-center">
        <video
          ref={videoRef}
          className="w-full h-full object-contain"
          controls
          autoPlay
          playsInline
          onClick={togglePlayPause}
        >
          <source src={currentSource} type="video/mp4" />
          {alternativeSources.map((src, index) => (
            <source key={index} src={src} type="video/mp4" />
          ))}
          Your browser does not support the video tag.
        </video>

        {/* Play/Pause Overlay */}
        {!isPlaying && (
          <div className="absolute inset-0 flex items-center justify-center">
            <Button
              onClick={togglePlayPause}
              className="bg-purple-500/80 hover:bg-purple-600/80 rounded-full w-20 h-20 p-0"
            >
              <Play className="w-10 h-10 ml-2" />
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
