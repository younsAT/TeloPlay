import TeloPlayApp from "../teloplay-app"

export default function Page() {
  return <TeloPlayApp />
}
