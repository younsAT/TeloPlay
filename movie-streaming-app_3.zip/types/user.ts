export interface User {
  id: string
  email: string
  name: string
  subscription: "free" | "premium"
  role: "user" | "admin"
  subscriptionExpiry?: Date
  registrationDate: Date
  lastLogin: Date
}

export interface Movie {
  id: string
  title: string
  year: string
  rating: number
  quality: string
  poster: string
  trailer: string
  duration: string
  genre: string[]
  description: string
  downloadUrl?: string
}

export interface AdminCredentials {
  username: string
  password: string
}

export interface PaymentInfo {
  telegram: string
  bankPortal: string
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  signup: (email: string, password: string, name: string) => Promise<boolean>
  adminLogin: (username: string, password: string) => Promise<boolean>
  logout: () => void
  loading: boolean
  updateUserSubscription: (userId: string, subscription: "free" | "premium", days?: number) => void
  getAllUsers: () => User[]
  isSubscriptionActive: (user: User) => boolean
  saveVisitor: (visitorData: Partial<User>) => User
}
