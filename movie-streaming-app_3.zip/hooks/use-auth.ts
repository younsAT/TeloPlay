"use client"

import type React from "react"
import { useState, useEffect, createContext, useContext } from "react"
import type { User } from "../types/user"

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  signup: (email: string, password: string, name: string) => Promise<boolean>
  adminLogin: (username: string, password: string) => Promise<boolean>
  logout: () => void
  loading: boolean
  updateUserSubscription: (userId: string, subscription: "free" | "premium", days?: number) => void
  getAllUsers: () => User[]
  isSubscriptionActive: (user: User) => boolean
  saveVisitor: (visitorData: Partial<User>) => User
}

const AuthContext = createContext<AuthContextType | null>(null)

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider")
  }
  return context
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  const ADMIN_CREDENTIALS = {
    username: "younsAvami",
    password: "younsAT55",
  }

  useEffect(() => {
    const savedUser = localStorage.getItem("teloplay-user")
    if (savedUser) {
      try {
        const parsedUser = JSON.parse(savedUser)
        // Convert date strings back to Date objects
        if (parsedUser.subscriptionExpiry) {
          parsedUser.subscriptionExpiry = new Date(parsedUser.subscriptionExpiry)
        }
        if (parsedUser.registrationDate) {
          parsedUser.registrationDate = new Date(parsedUser.registrationDate)
        }
        if (parsedUser.lastLogin) {
          parsedUser.lastLogin = new Date(parsedUser.lastLogin)
        }
        setUser(parsedUser)
      } catch (error) {
        console.error("Error parsing saved user:", error)
        // Don't clear localStorage on error, just continue
      }
    }
    setLoading(false)
  }, [])

  const saveUser = (userData: User) => {
    setUser(userData)
    localStorage.setItem("teloplay-user", JSON.stringify(userData))

    // Also save to users list
    const users = getAllUsers()
    const existingUserIndex = users.findIndex((u) => u.id === userData.id)
    if (existingUserIndex >= 0) {
      users[existingUserIndex] = userData
    } else {
      users.push(userData)
    }
    localStorage.setItem("teloplay-users", JSON.stringify(users))
  }

  const getAllUsers = (): User[] => {
    const users = localStorage.getItem("teloplay-users")
    if (users) {
      return JSON.parse(users).map((user: any) => ({
        ...user,
        subscriptionExpiry: user.subscriptionExpiry ? new Date(user.subscriptionExpiry) : undefined,
        registrationDate: new Date(user.registrationDate),
        lastLogin: new Date(user.lastLogin),
      }))
    }
    return []
  }

  const isSubscriptionActive = (user: User): boolean => {
    if (user.subscription === "premium" && user.subscriptionExpiry) {
      return new Date() < user.subscriptionExpiry
    }
    return false
  }

  const login = async (email: string, password: string): Promise<boolean> => {
    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (email && password) {
      const users = getAllUsers()
      const existingUser = users.find((u) => u.email === email)

      if (existingUser) {
        // Update last login
        existingUser.lastLogin = new Date()
        saveUser(existingUser)
        return true
      } else {
        // Create new user if doesn't exist (auto-registration)
        const now = new Date()
        const freeTrialExpiry = new Date(now.getTime() + 8 * 24 * 60 * 60 * 1000) // 8 days from now

        const newUser: User = {
          id: Date.now().toString(),
          email,
          name: email.split("@")[0], // Use email prefix as name
          subscription: "premium", // Start with premium for 8-day trial
          role: "user",
          subscriptionExpiry: freeTrialExpiry,
          registrationDate: now,
          lastLogin: now,
        }

        saveUser(newUser)
        return true
      }
    }
    return false
  }

  const signup = async (email: string, password: string, name: string): Promise<boolean> => {
    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (email && password && name) {
      const users = getAllUsers()
      const existingUser = users.find((u) => u.email === email)

      if (existingUser) {
        return false // User already exists
      }

      const now = new Date()
      const freeTrialExpiry = new Date(now.getTime() + 8 * 24 * 60 * 60 * 1000) // 8 days from now

      const newUser: User = {
        id: Date.now().toString(),
        email,
        name,
        subscription: "premium", // Start with premium for 8-day trial
        role: "user",
        subscriptionExpiry: freeTrialExpiry,
        registrationDate: now,
        lastLogin: now,
      }

      saveUser(newUser)
      return true
    }
    return false
  }

  const adminLogin = async (username: string, password: string): Promise<boolean> => {
    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (username === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password) {
      const adminUser: User = {
        id: "admin-1",
        email: "younsavami@teloplay.com",
        name: "Youns Avami",
        subscription: "premium",
        role: "admin",
        registrationDate: new Date(),
        lastLogin: new Date(),
      }
      setUser(adminUser)
      localStorage.setItem("teloplay-user", JSON.stringify(adminUser))
      return true
    }
    return false
  }

  const updateUserSubscription = (userId: string, subscription: "free" | "premium", days?: number) => {
    const users = getAllUsers()
    const userIndex = users.findIndex((u) => u.id === userId)

    if (userIndex >= 0) {
      users[userIndex].subscription = subscription
      if (subscription === "premium" && days) {
        const now = new Date()
        users[userIndex].subscriptionExpiry = new Date(now.getTime() + days * 24 * 60 * 60 * 1000)
      } else if (subscription === "free") {
        users[userIndex].subscriptionExpiry = undefined
      }

      localStorage.setItem("teloplay-users", JSON.stringify(users))

      // Update current user if it's the same user
      if (user && user.id === userId) {
        setUser(users[userIndex])
        localStorage.setItem("teloplay-user", JSON.stringify(users[userIndex]))
      }
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("teloplay-user")
  }

  const saveVisitor = (visitorData: Partial<User>) => {
    const now = new Date()
    const freeTrialExpiry = new Date(now.getTime() + 8 * 24 * 60 * 60 * 1000) // 8 days from now

    const visitor: User = {
      id: Date.now().toString(),
      email: visitorData.email || `visitor_${Date.now()}@teloplay.com`,
      name: visitorData.name || `Visitor ${Date.now()}`,
      subscription: "premium", // Start with premium for 8-day trial
      role: "user",
      subscriptionExpiry: freeTrialExpiry,
      registrationDate: now,
      lastLogin: now,
      ...visitorData,
    }

    saveUser(visitor)
    return visitor
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        signup,
        adminLogin,
        logout,
        loading,
        updateUserSubscription,
        getAllUsers,
        isSubscriptionActive,
        saveVisitor,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}
